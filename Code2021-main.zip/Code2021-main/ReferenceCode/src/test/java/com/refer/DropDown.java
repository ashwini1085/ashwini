package com.refer;

public enum DropDown {
Index{
	@Override
	public String toString() {
		return "Index";
	}
},
	Value
	{
		@Override
		public String toString() {
			return "Value";
		}
		},
		VisibleText{
			@Override
			public String toString() {
				return "VisibleText";
			}
			},

}
