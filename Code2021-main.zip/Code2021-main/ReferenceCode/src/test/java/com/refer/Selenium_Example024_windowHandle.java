package com.refer;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Selenium_Example024_windowHandle {
	static WebDriver driver;

	public static void WindowHandles(WebDriver WindowHandles) {
		System.setProperty("webdriver.chrome.driver", "D:\\Amruta\\ReferenceCode\\JarFiles\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.kotak.com/en/home.html");
		WebElement login = driver.findElement(By.xpath("//span[contains(text(),'Login')]"));
		login.click();
		System.out.println("Currentwindow Handle_Parent_Window:" + driver.getWindowHandle());

		Set<String> handles = driver.getWindowHandles();
		for (String handle : handles)
			System.out.println(handle);

	}

	public static void main(String[] args) {

		WindowHandles(driver);

	}
}
