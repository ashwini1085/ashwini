package com.refer;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Selenium_Example013_checkboxselection {
	static WebDriver driver;

	public static void main(String[] args) {

		login();
		check();

	}

	public static void login() {
		System.setProperty("webdriver.chrome.driver", "D:\\Amruta\\ReferenceCode\\JarFiles\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/recruitment/viewCandidates");
		driver.manage().window().maximize();
		WebElement e = driver.findElement(By.id("txtUsername"));
		e.sendKeys("Admin");
		e = driver.findElement(By.id("txtPassword"));
		e.sendKeys("admin123");
		e = driver.findElement(By.name("Submit"));
		e.click();

	}

	public static void check() {

		WebElement e = driver.findElement(By.xpath("//*[@id='ohrmList_chkSelectAll']"));

		for (int i = 0; i < 2; i++)

			if (!e.isSelected()) {

				e.click();
				System.out.println("Selected checkbox" + e.isSelected());
			}

			else {
				e.click();
				System.out.println("Checkbox was selected:" + e.isSelected());

			}

	}
}
