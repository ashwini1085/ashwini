package com.refer;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Selenium_Example049_rightclick_mouse_action {
static WebDriver driver;
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "D:\\Amruta\\ReferenceCode\\JarFiles\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://swisnl.github.io/jQuery-contextMenu/demo.html");
		driver.manage().window().maximize();
		test(driver);
		
	}
	public static void test(WebDriver driver){
		WebElement e = driver.findElement(By.xpath("html/body/div[1]/section/div/div/div/p/span"));
		Actions act = new Actions(driver);
		act.contextClick(e).build().perform();
		WebElement p = driver.findElement(By.xpath("html/body/ul/li[2]"));
		p.click();
	}

}
