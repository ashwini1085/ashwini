package com.refer;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Selenium_Example048_autosuggest {
static WebDriver driver;
	public static void main(String[] args) {
		// Example demonstrate key up functionality
		System.setProperty("webdriver.chrome.driver", "D:\\Amruta\\ReferenceCode\\JarFiles\\chromedriver.exe");
		driver = new ChromeDriver();
				driver.get("http://jqueryui.com/autocomplete/");
				driver.switchTo().frame(0);
				
				driver.manage().window().maximize();
				keyup(driver);
				
			}
				public static void keyup(WebDriver driver){
					
					WebElement tags = driver.findElement(By.xpath("//input[@class='ui-autocomplete-input']"));
					tags.sendKeys("c");					
					
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					WebElement we=driver.findElement(By.id("ui-id-1"));		
					List<WebElement> wel=we.findElements(By.tagName("li"));
					System.out.println(wel.size());
					wel.get(2).click();
					
		
				

				
			




	}
}


