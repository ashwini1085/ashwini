package com.refer;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Selenium_Example012_DynamicCheckboxamazon {

	static WebDriver driver;

	public static void verifycheckbox(String displayText) {

		System.setProperty("webdriver.chrome.driver", "D:\\Amruta\\ReferenceCode\\JarFiles\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.amazon.co.in");
		driver.manage().window().maximize();
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Mobiles",Keys.ENTER);
		WebElement checkbox =driver.findElement(By.xpath("//li[@aria-label='"+displayText+"']//input"));
		
		WebElement checkboxi =checkbox.findElement(By.xpath("//li[@aria-label='"+displayText+"']//i"));
	
		boolean state =checkboxi.isSelected();
		
		System.out.println("Checkbox is not checked"+" : "+state);
		if(!state) {
			checkboxi.click();
			
		}
	
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			
		}
	}

	public static void main(String[] args) {
		verifycheckbox("Get It by Tomorrow");

	}
}
