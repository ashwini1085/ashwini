package com.refer;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;
//How to handle dropdown in Selenium

public class Selenium_Example014_Dropdown_Approach4{
	static WebDriver driver;
	
	public static void main(String[] args) {
		init_driver();
		
		By country = By.name("Country");
		By employees = By.name("NoOfEmployees");
	//	doSelectByVisibleText(country, "Bahrain");
	
		selectOptionFromDropdown(employees, DropDown.Index.toString(),"2" );
		selectOptionFromDropdown(employees, DropDown.VisibleText.toString(),"51 - 75" );
		selectOptionFromDropdown(country, DropDown.Value.toString(),"Bahrain");

	}
	
	public static void init_driver() {
		System.setProperty("webdriver.chrome.driver", "D:\\Amruta\\ReferenceCode\\JarFiles\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.orangehrm.com/contact-sales/");
		driver.manage().window().maximize();
	}
	
	public static void selectOptionFromDropdown(By locator, String type, String value) {
	
		Select se = new Select(getElement(locator));
	
	switch (type) {
	case "Index":
		se.selectByIndex(Integer.parseInt(value));
		
		break;
		
	case "Value":
		se.selectByValue(value);
		
		break;
	case "VisibleText":
		
		se.selectByVisibleText(value);
	
		break;
		default:
			System.out.println("Please pass correct selection criteria");
			break;
	}
		
		
		}


	public static WebElement getElement(By locator) {
		
		return driver.findElement(locator);
	}
	/*
	 * public static void doSelectByVisibleText(By locator, String value) { 
	 * Select select = new Select(getElement(locator)); 
	 * select.selectByVisibleText(value);
	 * }
	 *  public static void doSelectByIndex(By locator, int index) 
	 *  {
	 *   Select select = new Select(getElement(locator));
	 *    select.selectByIndex(index);
	 *     }
	 *     public static void doSelectByValue(By locator, String value)
	 *      { 
	 *      Select select = newSelect(getElement(locator));
	 *       select.selectByValue(value); 
	 *       }
	 */ 
	}
		

