package com.refer;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Selenium_Example054_ReadProperty {
	static WebDriver driver;
	static FileInputStream fs;
	static Properties prop ;
  public static void main(String[] args) throws FileNotFoundException  
  {
	  readdata();
	  
  }
  public static void readdata() throws FileNotFoundException 
  {
	  String file = "D:\\SeleniumCode\\utility\\config.properties";
	  fs = new FileInputStream(file);
		try {
			fs = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		 prop = new Properties();
		
		//load properties file
		try {
			prop.load(fs);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.setProperty("webdriver.chrome.driver", "D:\\Amruta\\ReferenceCode\\JarFiles\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();

		driver.get(prop.getProperty("URL"));
		driver.findElement(By.id("txtUsername")).sendKeys(prop.getProperty("Username"));
		driver.findElement(By.id("txtPassword")).sendKeys(prop.getProperty("Password"));
		driver.findElement(By.id("btnLogin")).click();
		
		
		System.out.println("URL ::" + prop.getProperty("URL"));
		System.out.println("Username::" +prop.getProperty("Username"));
	    System.out.println("Password::" +prop.getProperty("Password"));
  }
}
