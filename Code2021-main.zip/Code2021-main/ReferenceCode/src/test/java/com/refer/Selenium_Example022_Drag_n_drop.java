package com.refer;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Selenium_Example022_Drag_n_drop {
static WebDriver driver;
	public static void main(String[] args) {
		
		
		launchbrowser();
		 WebElement e = driver.findElement(By.id("item5")); 
		 WebElement e1 = driver.findElement(By.id("item1"));
		 dragndrop(driver, e, e1);
		 
	}
	
	public static void launchbrowser()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Amruta\\ReferenceCode\\JarFiles\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://executeautomation.com/demosite/Dragging.html");
		driver.manage().window().maximize();
		
		
	}
	public static void dragndrop(WebDriver driver, WebElement srcElement, WebElement dstElement)
	{
		Actions action = new Actions(driver);
		action.dragAndDrop(srcElement, dstElement).build().perform();
	}

}
