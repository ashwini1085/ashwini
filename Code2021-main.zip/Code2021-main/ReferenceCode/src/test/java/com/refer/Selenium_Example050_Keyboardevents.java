package com.refer;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class Selenium_Example050_Keyboardevents {
static WebDriver driver;
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "D:\\Amruta\\ReferenceCode\\JarFiles\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://jqueryui.com/selectable/");
		driver.manage().window().maximize();
		driver.switchTo().frame(0);
		clickHold(driver);

	}
	public static void clickHold(WebDriver driver){
		Actions act = new Actions(driver);
		act.keyDown(Keys.CONTROL);
		java.util.List<WebElement> L= driver.findElements(By.cssSelector("ol#selectable *"));
		System.out.println(L.size());
		act.click(L.get(3));
		act.click(L.get(4));
		act.keyUp(Keys.CONTROL);
	    act.build().perform();
	}

}
