package com.StepDefination;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class StepDefination {
static WebDriver driver;
	

@Given("User is on Home Page")
public void user_is_on_home_page() {
   
  System.out.println("user is on orangehrm page");
}
@When("User Navigate to LogIn Page")
public void user_navigate_to_log_in_page() {
	WebDriverManager.chromedriver().setup();
    driver = new ChromeDriver();
   driver.get("https://opensource-demo.orangehrmlive.com/index.php/auth/login");
   driver.manage().window().maximize();

}
@When("User enters Credentials to LogIn")
public void user_enters_credentials_to_log_in(io.cucumber.datatable.DataTable usercredentials) {
	List<Map<String,String>> data = usercredentials.asMaps(String.class,String.class);
	driver.findElement(By.id("txtUsername")).sendKeys(data.get(0).get("Username")); 
    driver.findElement(By.id("txtPassword")).sendKeys(data.get(0).get("Password"));
    driver.findElement(By.id("btnLogin")).click();
}
@Then("Message displayed Login Successfully")
public void message_displayed_login_successfully() {
   
}
}
