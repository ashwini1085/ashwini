package com.StepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class StepDefination {
	static WebDriver driver;
	@Given("User is on Home Page")
	public void user_is_on_home_page() {
	 System.out.println("User is on homepage of OrangeHRM");
	}
	@When("user navigates to Login Page")
	public void user_navigates_to_login_page() {
	    WebDriverManager.chromedriver().setup();
	     driver = new ChromeDriver();
	    driver.get("https://opensource-demo.orangehrmlive.com/index.php/auth/login");
	    driver.manage().window().maximize();
	}
	@When("User enters {string} and {string} And click on login button")
	public void user_enters_and_and_click_on_login_button(String uName, String pwd){
	   
		WebElement username = driver.findElement(By.xpath("//input[@name='txtUsername']"));
		username.sendKeys(uName);
		WebElement password = driver.findElement(By.xpath("//input[@type='password']"));
		password.sendKeys(pwd);
		WebElement loginBtn = driver.findElement(By.xpath("//*[@value='LOGIN']"));
		loginBtn.click();
	}
	@Then("Message displayed login successfully.")
	public void message_displayed_login_successfully() {
	    
	}



}
