package com.StepDefination;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class StepDefination {
	static WebDriver driver;

	@Given("User is on Home Page")
	public void user_is_on_home_page() {

		System.out.println("user is on orangehrm page");
	}

	@When("User Navigate to LogIn Page")
	public void user_navigate_to_log_in_page() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/auth/login");
		driver.manage().window().maximize();

	}

	@When("User enters Credentials to LogIn")
	public void user_enters_credentials_to_log_in(DataTable usercredentials) {

		List<Map<String, String>> login = usercredentials.asMaps();

		for (Map<String, String> form : login) {

			String userName = form.get("Username");
			System.out.println("Username :" + userName);

			WebElement username = driver.findElement(By.name("txtUsername"));
			username.sendKeys(userName);

			String passWord = form.get("Password");
			System.out.println("Password :" + passWord);

			WebElement password = driver.findElement(By.name("txtPassword"));
			password.sendKeys(passWord);

			driver.findElement(By.id("btnLogin")).submit();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			WebElement e = driver.findElement(By.id("welcome"));
			e.click();
			Actions a = new Actions(driver);

			WebElement logout = driver.findElement(By.xpath("//*[@id='welcome-menu']/ul/li[3]/a"));
			a.moveToElement(logout).build().perform();
			logout.click();
		}
	}

	@Then("Message displayed Login Successfully")
	public void message_displayed_login_successfully() {

	}
}
