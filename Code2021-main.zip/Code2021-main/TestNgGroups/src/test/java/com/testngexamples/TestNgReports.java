package com.testngexamples;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestNgReports {
	//When we run this test, there are two separate sections in the Eclipse where these reports are visible.

//Console=>console also shows a bunch of process commands from TestNG that we do not need to bother. If there is any hindrance in running these tests, 
	//the error commands display in the console tab only. The console works like a typical console in every language.
//TestNG Report Section In Eclipse=>TestNG provides the class name and the function name that
	
	/*How To Generate Emailable Report In TestNG?
	Emailable reports are generated in TestNG to let the user send their test reports to other team members. Emailable-reports do not require any extra work from the tester, and they are a part of overall test execution. To generate emailable reports, first, run the TestNG test class if you have not already.

	Once we have run the test case, a new folder generates in the same directory with the name test-output.*/
	
	  WebDriver driver ;
	    @Test
	    public void f() {
	    	System.setProperty("webdriver.chrome.driver", "D:\\Amruta\\ReferenceCode\\JarFiles\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
		   String baseUrl = "https://opensource-demo.orangehrmlive.com/";
		   System.out.println("Launching Google Chrome browser"); 
		   driver = new ChromeDriver();
		   driver.get(baseUrl);
		   driver.manage().window().maximize();
		   String testTitle = "Orange HRM";
		   String originalTitle = driver.getTitle();
		   Assert.assertEquals(originalTitle, testTitle);
	   }
		
	   @BeforeMethod
	    public void beforeMethod() {
		System.out.println("Starting Test On Chrome Browser");
	    }
		
	    @AfterMethod
	     public void afterMethod() {
		
		 System.out.println("Finished Test On Chrome Browser");
	    }
	
}
