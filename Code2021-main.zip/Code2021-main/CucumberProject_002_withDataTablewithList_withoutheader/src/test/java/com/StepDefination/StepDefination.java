package com.StepDefination;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import io.github.bonigarcia.wdm.WebDriverManager;

public class StepDefination {
	static WebDriver driver;

	@Given("User is on Home Page")
	public void user_is_on_home_page() {
		System.out.println("User is on homepage of OrangeHRM");
	}

	@When("user navigates to Login Page")
	public void user_navigates_to_login_page() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/auth/login");
		driver.manage().window().maximize();
	}

	@When("User enters credentials to Login And click on login button")
	public void user_enters_credentials_to_login_and_click_on_login_button(DataTable usercredentials) {
		List<List<String>> data = usercredentials.asLists();
		for (List<String> li : data) {
			System.out.println(li);
			WebElement username = driver.findElement(By.xpath("//input[@name='txtUsername']"));
			username.sendKeys(li.get(0));

			WebElement password = driver.findElement(By.id("txtPassword"));
			password.sendKeys(li.get(1));
			driver.findElement(By.xpath("//input[@id='btnLogin']")).click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			
			 
		}

	}

	@Then("Message displayed login successfully.")
	public void message_displayed_login_successfully() {
		System.out.println("login done successfully");

	}

}
